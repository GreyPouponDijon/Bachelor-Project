/*
 * Copyright (c) 2021 Bosch Sensortec GmbH
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * Copyright (c) 2022 - 2023, Nordic Semiconductor ASA
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/drivers/watchdog.h>
#include <zephyr/sys/reboot.h>
#include <zephyr/task_wdt/task_wdt.h>
#include <zephyr/drivers/gpio.h>
#include <stdio.h>
#include <math.h>
#include <stdbool.h>
#include <zephyr/sys/printk.h>
#include <nrfx_timer.h>

#pragma region

#define Gravity_const 9.81f

#define Math_Pi 3.14159265358979323846f

#define COMP_FILT_ALPHA 0.05f

#define Sampletime 10.0f

#define LED0_NODE DT_ALIAS(led0)
#define LED1_NODE DT_ALIAS(led1)
#define LED2_NODE DT_ALIAS(led2)
#define LED3_NODE DT_ALIAS(led3)

/** @brief Symbol specifying timer instance to be used. */
#define TIMER_INST_IDX 0

/** @brief Symbol specifying time in milliseconds to wait for handler execution. */
#define TIME_TO_WAIT_MS 10UL

static const struct gpio_dt_spec led0 = GPIO_DT_SPEC_GET(LED0_NODE, gpios);
static const struct gpio_dt_spec led1 = GPIO_DT_SPEC_GET(LED1_NODE, gpios);
static const struct gpio_dt_spec led2 = GPIO_DT_SPEC_GET(LED2_NODE, gpios);
static const struct gpio_dt_spec led3 = GPIO_DT_SPEC_GET(LED3_NODE, gpios);

volatile uint8_t Nancounter;

typedef struct 
{
	uint8_t led;
	float frequency;
	uint32_t counter;
	uint32_t period;
} Directions;

Directions Channels[4] = {
	{.led = 1, .frequency = 0.0f, .counter = 0, .period = 0},
	{.led = 2, .frequency = 0.0f, .counter =  0,  .period = 0},
	{.led = 3, .frequency = 0.0f, .counter = 0, 0,  .period = 0},
	{.led = 4, .frequency = 0.0f, .counter = 0, 0,  .period = 0}
};



#pragma endregion

#pragma region 

#if DT_NODE_HAS_STATUS(DT_ALIAS(watchdog0), okay)
#define WDT_NODE DT_ALIAS(watchdog0)
#elif DT_HAS_COMPAT_STATUS_OKAY(st_stm32_window_watchdog)
#define WDT_NODE DT_COMPAT_GET_ANY_STATUS_OKAY(st_stm32_window_watchdog)
#elif DT_HAS_COMPAT_STATUS_OKAY(st_stm32_watchdog)
#define WDT_NODE DT_COMPAT_GET_ANY_STATUS_OKAY(st_stm32_watchdog)
#elif DT_HAS_COMPAT_STATUS_OKAY(nordic_nrf_wdt)
#define WDT_NODE DT_COMPAT_GET_ANY_STATUS_OKAY(nordic_nrf_wdt)
#elif DT_HAS_COMPAT_STATUS_OKAY(espressif_esp32_watchdog)
#define WDT_NODE DT_COMPAT_GET_ANY_STATUS_OKAY(espressif_esp32_watchdog)
#elif DT_HAS_COMPAT_STATUS_OKAY(silabs_gecko_wdog)
#define WDT_NODE DT_COMPAT_GET_ANY_STATUS_OKAY(silabs_gecko_wdog)
#elif DT_HAS_COMPAT_STATUS_OKAY(nxp_kinetis_wdog32)
#define WDT_NODE DT_COMPAT_GET_ANY_STATUS_OKAY(nxp_kinetis_wdog32)
#elif DT_HAS_COMPAT_STATUS_OKAY(microchip_xec_watchdog)
#define WDT_NODE DT_COMPAT_GET_ANY_STATUS_OKAY(microchip_xec_watchdog)
#else
#define WDT_NODE DT_INVALID_NODE
#endif

#pragma endregion

static void task_wdt_callback(int channel_id, void *user_data)
{
	printk("Task watchdog channel %d callback, thread: %s\n",
		channel_id, k_thread_name_get((k_tid_t)user_data));

	/*
	 * If the issue could be resolved, call task_wdt_feed(channel_id) here
	 * to continue operation.
	 *
	 * Otherwise we can perform some cleanup and reset the device.
	 */

	printk("Resetting device...\n");

	sys_reboot(SYS_REBOOT_COLD);
}

static void timer_handler(nrf_timer_event_t event_type, void * p_context)
{
    if(event_type == NRF_TIMER_EVENT_COMPARE0)
    {
        char * p_msg = p_context;
       for (int i = 0; i < 4; i++)
       {
		   updateLeds(&Channels[i]);
	   }
    }
}

float clip(float n, float lower, float upper) {
    if (n < lower) return lower;
	if (n > upper) return upper;	
	return n;
}

void setLedsPeriod(Directions *Channels, float led_period)
{
	float frequency = 0.1f + (0.9 * led_period);
	Channels ->period = (unsigned int)(100/frequency);
}

void updateLeds(Directions *Channels)
{
	int ret;
	Channels->counter++;
	if (Channels->counter >= Channels->period)
	{
		Channels->counter = 0;
	}

	if (Channels->counter < Channels->period/10)
	{
		switch (Channels->led)
		{
		case 1:
		ret = gpio_pin_set_dt(&led0,0);
		if (ret < 0) {
			return 0;
		}
		break;
		case 2:
		ret = gpio_pin_set_dt(&led1,0);
		if (ret < 0) {
			return 0;
		}
		break;
		case 3:
		ret = gpio_pin_set_dt(&led2,0);
		if (ret < 0) {
			return 0;
		}
		break;
		case 4:
		ret = gpio_pin_set_dt(&led3,0);
		if (ret < 0) {
			return 0;
		}
		default:
			break;
		}
	}

	else
	{
		switch (Channels->led)
		{
		case 1:
		ret = gpio_pin_set_dt(&led0,1);
		if (ret < 0) {
			return 0;
		}
		break;
		case 2:
		ret = gpio_pin_set_dt(&led1,1);
		if (ret < 0) {
			return 0;
		}
		break;
		case 3:
		ret = gpio_pin_set_dt(&led2,1);
		if (ret < 0) {
			return 0;
		}
		break;
		case 4:
		ret = gpio_pin_set_dt(&led3,1);
		if (ret < 0) {
			return 0;
		}
		default:
		break;
		}
	}
}

float led_period(uint8_t led,float phi, float theta)
{
	float value;

	if (phi > 1.0f)
	{
		phi = 1.0;
	}

	else if (phi < -1.0f)
	{
		phi = -1.0;
	}

	if (theta > 1.0f)
	{
		theta = 1.0;
	}

	else if (theta < -1.0f)
	{
		theta = -1.0;
	}
	switch (led)
	{
		case 1:
			value = clip((1-fabs(phi+1))*(1-fabs(theta)),0,1);
		break;
		case 2:
			value = clip((1-fabs(theta+1))*(1-fabs(phi)),0,1);
		break;
		case 3:
			value = clip((1-fabs(phi-1))*(1-fabs(theta)),0,1);
		break;
		case 4:
			value = clip((1-fabs(theta-1))*(1-fabs(phi)),0,1);
		break;
	
	default:
		break;
	}
	return value;
}

void setLedparameters(Directions *Channels, float phi, float theta)
{
	for (int i = 0; i < 4; i++)
	{
		Channels[i].frequency = led_period(Channels[i].led, phi, theta);
		printk("LED: %d; Frequency: %f\n", Channels[i].led, Channels[i].frequency);
		setLedsPeriod(&Channels[i], Channels[i].frequency);
	}
}


int main(void)
{

	float phiHat = 0.0f;
	float thetaHat = 0.0f;
	int ret;

	int err;

	nrfx_err_t status;
    (void)status;

	nrfx_timer_t timer_inst = NRFX_TIMER_INSTANCE(TIMER_INST_IDX);
    uint32_t base_frequency = NRF_TIMER_BASE_FREQUENCY_GET(timer_inst.p_reg);
    nrfx_timer_config_t config = NRFX_TIMER_DEFAULT_CONFIG(base_frequency);
    config.bit_width = NRF_TIMER_BIT_WIDTH_32;
    config.p_context = "Some context";

	status = nrfx_timer_init(&timer_inst, &config, timer_handler);
    NRFX_ASSERT(status == NRFX_SUCCESS);

	#if defined(__ZEPHYR__)
    IRQ_DIRECT_CONNECT(NRFX_IRQ_NUMBER_GET(NRF_TIMER_INST_GET(TIMER_INST_IDX)), IRQ_PRIO_LOWEST,
                       NRFX_TIMER_INST_HANDLER_GET(TIMER_INST_IDX), 0);
	#endif

	 nrfx_timer_clear(&timer_inst);

    /* Creating variable desired_ticks to store the output of nrfx_timer_ms_to_ticks function */
    uint32_t desired_ticks = nrfx_timer_ms_to_ticks(&timer_inst, TIME_TO_WAIT_MS);
    printk("Time to wait: %lu ms", TIME_TO_WAIT_MS);

    /*
     * Setting the timer channel NRF_TIMER_CC_CHANNEL0 in the extended compare mode to clear the timer and
     * trigger an interrupt if internal counter register is equal to desired_ticks.
     */
    nrfx_timer_extended_compare(&timer_inst, NRF_TIMER_CC_CHANNEL0, desired_ticks,
                                NRF_TIMER_SHORT_COMPARE0_CLEAR_MASK, true);

    nrfx_timer_enable(&timer_inst);
    printk("Timer status: %s", nrfx_timer_is_enabled(&timer_inst) ? "enabled" : "disabled");


	const struct device *const hw_wdt_dev = DEVICE_DT_GET_OR_NULL(WDT_NODE);
	
	const struct device *const dev = DEVICE_DT_GET_ONE(bosch_bmi270);
	struct sensor_value acc[3], gyr[3];
	struct sensor_value full_scale, sampling_freq, oversampling;

	if (!device_is_ready(dev)) {
		printk("Device %s is not ready\n", dev->name);
		return 0;
	}

	printk("Device %p name is %s\n", dev, dev->name);

	if (!device_is_ready(hw_wdt_dev)) {
		printk("Hardware watchdog not ready; ignoring it.\n");
	}

	ret = task_wdt_init(hw_wdt_dev);
	if (ret != 0) {
		printk("task wdt init failure: %d\n", ret);
		return 0;
	}

		if (!gpio_is_ready_dt(&led0)) {
		return 0;
	}

		if (!gpio_is_ready_dt(&led1)) {
		return 0;
	}

		if (!gpio_is_ready_dt(&led2)) {
		return 0;
	}

		if (!gpio_is_ready_dt(&led3)) {
		return 0;
	}

	ret = gpio_pin_configure_dt(&led0, GPIO_OUTPUT_ACTIVE);
	if (ret < 0) {
		return 0;
	}

	ret = gpio_pin_configure_dt(&led1, GPIO_OUTPUT_ACTIVE);
	if (ret < 0) {
		return 0;
	}

	ret = gpio_pin_configure_dt(&led2, GPIO_OUTPUT_ACTIVE);
	if (ret < 0) {
		return 0;
	}

	ret = gpio_pin_configure_dt(&led3, GPIO_OUTPUT_ACTIVE);
	if (ret < 0) {
		return 0;
	}

	/* Setting scale in G, due to loss of precision if the SI unit m/s^2
	 * is used
	 */
	full_scale.val1 = 2;            /* G */
	full_scale.val2 = 0;
	sampling_freq.val1 = 100;       /* Hz. Performance mode */
	sampling_freq.val2 = 0;
	oversampling.val1 = 1;          /* Normal mode */
	oversampling.val2 = 0;

	sensor_attr_set(dev, SENSOR_CHAN_ACCEL_XYZ, SENSOR_ATTR_FULL_SCALE,
			&full_scale);
	sensor_attr_set(dev, SENSOR_CHAN_ACCEL_XYZ, SENSOR_ATTR_OVERSAMPLING,
			&oversampling);
	/* Set sampling frequency last as this also sets the appropriate
	 * power mode. If already sampling, change to 0.0Hz before changing
	 * other attributes
	 */
	sensor_attr_set(dev, SENSOR_CHAN_ACCEL_XYZ,
			SENSOR_ATTR_SAMPLING_FREQUENCY,
			&sampling_freq);


	/* Setting scale in degrees/s to match the sensor scale */
	full_scale.val1 = 500;          /* dps */
	full_scale.val2 = 0;
	sampling_freq.val1 = 100;       /* Hz. Performance mode */
	sampling_freq.val2 = 0;
	oversampling.val1 = 1;          /* Normal mode */
	oversampling.val2 = 0;

	sensor_attr_set(dev, SENSOR_CHAN_GYRO_XYZ, SENSOR_ATTR_FULL_SCALE,
			&full_scale);
	sensor_attr_set(dev, SENSOR_CHAN_GYRO_XYZ, SENSOR_ATTR_OVERSAMPLING,
			&oversampling);
	/* Set sampling frequency last as this also sets the appropriate
	 * power mode. If already sampling, change sampling frequency to
	 * 0.0Hz before changing other attributes
	 */
	sensor_attr_set(dev, SENSOR_CHAN_GYRO_XYZ,
			SENSOR_ATTR_SAMPLING_FREQUENCY,
			&sampling_freq);

	/* passing NULL instead of callback to trigger system reset */
	int task_wdt_id = task_wdt_add(1100U, NULL, NULL);

		ret = gpio_pin_toggle_dt(&led0);
		if (ret < 0) {
			return 0;
		}

		ret = gpio_pin_toggle_dt(&led1);
		if (ret < 0) {
			return 0;
		}

		ret = gpio_pin_toggle_dt(&led2);
		if (ret < 0) {
			return 0;
		}

		ret = gpio_pin_toggle_dt(&led3);
		if (ret < 0) {
			return 0;
		}

	while (1) {
		/* 10ms period, 100Hz Sampling frequency */
		k_sleep(K_MSEC(Sampletime));

		sensor_sample_fetch(dev);

		sensor_channel_get(dev, SENSOR_CHAN_ACCEL_XYZ, acc);
		sensor_channel_get(dev, SENSOR_CHAN_GYRO_XYZ, gyr);

				//convesrion formula from sensor.h definition
			   float ax = (acc[0].val1+acc[0].val2*1e-6);
			   float ay = (acc[1].val1+acc[1].val2*1e-6);
			   float az = (acc[2].val1+acc[2].val2*1e-6);

			   //printk("AX: %f; AY: %f; AZ: %f\n", ax, ay, az);

			   //Estimation of the angle using the accelerometer values
			   //Theoretical proof and code from https://www.youtube.com/watch?v=BUW2OdAtzBw
			   float phiHat_acc_g = atanf(ay/az);
			   float thetaHat_acc_g = asinf(ax/Gravity_const);

			   if (isnan(phiHat_acc_g)) {
				   printk("PhiHat is NaN\n");
				   Nancounter++;
				   phiHat_acc_g = 0.0f;
			   }

			   else{}

			   if (isnan(thetaHat_acc_g)) {
				   printk("ThetaHat is NaN\n");
				   thetaHat_acc_g = 0.0f;
				   Nancounter++;
			   }

			   else{}

			   //printk("PhiAcc: %f; ThetaAcc: %f\n", phiHat_acc_g, thetaHat_acc_g);

			   //Gyroscope values
			   float gx = (gyr[0].val1+gyr[0].val2*1e-6);
			   float gy = (gyr[1].val1+gyr[1].val2*1e-6);
			   float gz = (gyr[2].val1+gyr[2].val2*1e-6);

			   //printk("GX: %f; GY: %f; GZ: %f\n", gx, gy, gz);

			   float phiDot_rps = gx + tanf(thetaHat_acc_g) * (sinf(phiHat_acc_g) * gy + cosf(phiHat_acc_g) * gz);
			   float thetaDot_rps = cosf(phiHat_acc_g) * gy - sinf(phiHat_acc_g) * gz;

			   	if (isnan(phiDot_rps)) {
				   printk("PhiDot is NaN\n");
				   phiHat_acc_g = 0.0f;
			   }

			   else{}

			   if (isnan(thetaDot_rps)) {
				   printk("ThetaDot is NaN\n");
				   thetaHat_acc_g = 0.0f;
			   }

			   else{}

			   //printk("PhiDot: %f; ThetaDot: %f\n", phiDot_rps, thetaDot_rps);

			   //Complementary filter
			   phiHat = COMP_FILT_ALPHA * phiHat_acc_g + (1.0f - COMP_FILT_ALPHA) * (phiHat + (Sampletime / 1000.0f) * phiDot_rps);
			   thetaHat = COMP_FILT_ALPHA * thetaHat_acc_g + (1.0f - COMP_FILT_ALPHA) * (thetaHat + (Sampletime/1000.0f) * thetaDot_rps);

			   setLedparameters(&Channels,phiHat,thetaHat);

			if (Nancounter >= 45)
			{
				printk("Too many NaNs\n");
				k_sleep(K_MSEC(1000));
			}

			else{
				task_wdt_feed(task_wdt_id);
			}
			


	}
	return 0;
}

void reset_thread(void)
{
	int task_wdt_id;

	task_wdt_id = task_wdt_add(700U, task_wdt_callback, (void *)k_current_get());

	while(1) {
		if (Nancounter >= 45)
		{
			printk("Too many NaNs\n");
			k_sleep(K_FOREVER);
		}

		else{
			task_wdt_feed(task_wdt_id);
			k_sleep(K_MSEC(Sampletime*5));
		}



	}
}

K_THREAD_DEFINE(reset, 1024, reset_thread, NULL, NULL, NULL, -1, 0, 1000);
