/*
 * Copyright (c) 2021 Bosch Sensortec GmbH
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/drivers/watchdog.h>
#include <zephyr/sys/reboot.h>
#include <zephyr/task_wdt/task_wdt.h>
#include <zephyr/drivers/gpio.h>
#include <stdio.h>
#include <math.h>
#include <stdbool.h>
#include <zephyr/sys/printk.h>
#include <zephyr/drivers/pwm.h>

#pragma region

#define PWM_LED0 DT_ALIAS(pwm_led0)

#define SERVO_MOTOR     DT_NODELABEL(servo)

#define LEFT_ARROW      DT_NODELABEL(left)

#define RIGHT_ARROW      DT_NODELABEL(right)

#define Gravity_const 9.81f

#define Math_Pi 3.14159265358979323846f

#define COMP_FILT_ALPHA 0.05f

#define Sampletime 100.0f

#define PWM_PERIOD   PWM_MSEC(20)


static const struct pwm_dt_spec pwm_led0 = PWM_DT_SPEC_GET(PWM_LED0);

static const struct pwm_dt_spec pwm_servo = PWM_DT_SPEC_GET(DT_NODELABEL(servo));

static const struct pwm_dt_spec pwm_left = PWM_DT_SPEC_GET(DT_NODELABEL(left));

static const struct pwm_dt_spec pwm_right = PWM_DT_SPEC_GET(DT_NODELABEL(right));



#define PWM_MIN_PERIOD   DT_PROP(SERVO_MOTOR, min_pulse)
#define PWM_MAX_PERIOD  DT_PROP(SERVO_MOTOR, max_pulse)

volatile uint8_t Nancounter;

#pragma endregion

#pragma region 

#if DT_NODE_HAS_STATUS(DT_ALIAS(watchdog0), okay)
#define WDT_NODE DT_ALIAS(watchdog0)
#elif DT_HAS_COMPAT_STATUS_OKAY(st_stm32_window_watchdog)
#define WDT_NODE DT_COMPAT_GET_ANY_STATUS_OKAY(st_stm32_window_watchdog)
#elif DT_HAS_COMPAT_STATUS_OKAY(st_stm32_watchdog)
#define WDT_NODE DT_COMPAT_GET_ANY_STATUS_OKAY(st_stm32_watchdog)
#elif DT_HAS_COMPAT_STATUS_OKAY(nordic_nrf_wdt)
#define WDT_NODE DT_COMPAT_GET_ANY_STATUS_OKAY(nordic_nrf_wdt)
#elif DT_HAS_COMPAT_STATUS_OKAY(espressif_esp32_watchdog)
#define WDT_NODE DT_COMPAT_GET_ANY_STATUS_OKAY(espressif_esp32_watchdog)
#elif DT_HAS_COMPAT_STATUS_OKAY(silabs_gecko_wdog)
#define WDT_NODE DT_COMPAT_GET_ANY_STATUS_OKAY(silabs_gecko_wdog)
#elif DT_HAS_COMPAT_STATUS_OKAY(nxp_kinetis_wdog32)
#define WDT_NODE DT_COMPAT_GET_ANY_STATUS_OKAY(nxp_kinetis_wdog32)
#elif DT_HAS_COMPAT_STATUS_OKAY(microchip_xec_watchdog)
#define WDT_NODE DT_COMPAT_GET_ANY_STATUS_OKAY(microchip_xec_watchdog)
#else
#define WDT_NODE DT_INVALID_NODE
#endif

#pragma endregion

static void task_wdt_callback(int channel_id, void *user_data)
{
	printk("Task watchdog channel %d callback, thread: %s\n",
		channel_id, k_thread_name_get((k_tid_t)user_data));

	/*
	 * If the issue could be resolved, call task_wdt_feed(channel_id) here
	 * to continue operation.
	 *
	 * Otherwise we can perform some cleanup and reset the device.
	 */

	printk("Resetting device...\n");

	sys_reboot(SYS_REBOOT_COLD);
}

int writePWMfrominput(uint32_t pwm1,uint32_t pwm2,uint32_t pwm3,uint32_t pwm4)
{
	int err;
	    err = pwm_set_dt(&pwm_led0, pwm1, pwm1/2 );
    if (err) {
        printk("pwm_set_dt returned %d", err);
        return 0;
    }

	err = pwm_set_dt(&pwm_servo, pwm2, pwm2/2 );
    if (err) {
        printk("pwm_set_dt returned %d", err);
        return 0;
    }

	err = pwm_set_dt(&pwm_left, pwm3, pwm3/2 );
	if (err) {
		printk("pwm_set_dt returned %d", err);
		return 0;
	}

	err = pwm_set_dt(&pwm_right,pwm4, pwm4/2  );
	if (err) {
		printk("pwm_set_dt returned %d", err);
		return 0;
	}


}

float clip(float n, float lower, float upper) {
    if (n < lower) return lower;
	if (n > upper) return upper;	
	return n;
}

float led_period(uint8_t led,float phi, float theta)
{
	float value;

	if (phi > 1.0f)
	{
		phi = 1.0;
	}

	else if (phi < -1.0f)
	{
		phi = -1.0;
	}

	if (theta > 1.0f)
	{
		theta = 1.0;
	}

	else if (theta < -1.0f)
	{
		theta = -1.0;
	}
	switch (led)
	{
		case 1:
			value = clip((1-fabs(phi+1))*(1-fabs(theta)),0,1);
		break;
		case 2:
			value = clip((1-fabs(theta+1))*(1-fabs(phi)),0,1);
		break;
		case 3:
			value = clip((1-fabs(phi-1))*(1-fabs(theta)),0,1);
		break;
		case 4:
			value = clip((1-fabs(theta+1))*(1-fabs(phi)),0,1);
		break;
	
	default:
		break;
	}
	return value;
}


uint32_t ConvertAngleToPWM(float led_period)
{
	return(led_period-0)*(PWM_MAX_PERIOD-PWM_MIN_PERIOD)/(1-0)+PWM_MIN_PERIOD;
}


int main(void)
{

	float phiHat = 0.0f;
	float thetaHat = 0.0f;
	int ret;

	int err;

	const struct device *const hw_wdt_dev = DEVICE_DT_GET_OR_NULL(WDT_NODE);
	
	const struct device *const dev = DEVICE_DT_GET_ONE(bosch_bmi270);
	struct sensor_value acc[3], gyr[3];
	struct sensor_value full_scale, sampling_freq, oversampling;

	if (!device_is_ready(dev)) {
		printk("Device %s is not ready\n", dev->name);
		return 0;
	}

	printk("Device %p name is %s\n", dev, dev->name);

	if (!pwm_is_ready_dt(&pwm_led0)) {
	printk("Error: PWM device %s is not ready\n", pwm_led0.dev->name);
	return 0;
	}

	if (!device_is_ready(hw_wdt_dev)) {
		printk("Hardware watchdog not ready; ignoring it.\n");
	}

	ret = task_wdt_init(hw_wdt_dev);
	if (ret != 0) {
		printk("task wdt init failure: %d\n", ret);
		return 0;
	}



	/* Setting scale in G, due to loss of precision if the SI unit m/s^2
	 * is used
	 */
	full_scale.val1 = 2;            /* G */
	full_scale.val2 = 0;
	sampling_freq.val1 = 100;       /* Hz. Performance mode */
	sampling_freq.val2 = 0;
	oversampling.val1 = 1;          /* Normal mode */
	oversampling.val2 = 0;

	sensor_attr_set(dev, SENSOR_CHAN_ACCEL_XYZ, SENSOR_ATTR_FULL_SCALE,
			&full_scale);
	sensor_attr_set(dev, SENSOR_CHAN_ACCEL_XYZ, SENSOR_ATTR_OVERSAMPLING,
			&oversampling);
	/* Set sampling frequency last as this also sets the appropriate
	 * power mode. If already sampling, change to 0.0Hz before changing
	 * other attributes
	 */
	sensor_attr_set(dev, SENSOR_CHAN_ACCEL_XYZ,
			SENSOR_ATTR_SAMPLING_FREQUENCY,
			&sampling_freq);


	/* Setting scale in degrees/s to match the sensor scale */
	full_scale.val1 = 500;          /* dps */
	full_scale.val2 = 0;
	sampling_freq.val1 = 100;       /* Hz. Performance mode */
	sampling_freq.val2 = 0;
	oversampling.val1 = 1;          /* Normal mode */
	oversampling.val2 = 0;

	sensor_attr_set(dev, SENSOR_CHAN_GYRO_XYZ, SENSOR_ATTR_FULL_SCALE,
			&full_scale);
	sensor_attr_set(dev, SENSOR_CHAN_GYRO_XYZ, SENSOR_ATTR_OVERSAMPLING,
			&oversampling);
	/* Set sampling frequency last as this also sets the appropriate
	 * power mode. If already sampling, change sampling frequency to
	 * 0.0Hz before changing other attributes
	 */
	sensor_attr_set(dev, SENSOR_CHAN_GYRO_XYZ,
			SENSOR_ATTR_SAMPLING_FREQUENCY,
			&sampling_freq);

	/* passing NULL instead of callback to trigger system reset */
	int task_wdt_id = task_wdt_add(1100U, NULL, NULL);

    if (!pwm_is_ready_dt(&pwm_led0)) {
        printk("Error: PWM device %s is not ready", pwm_led0.dev->name);
        return 0;
	}


	if (!pwm_is_ready_dt(&pwm_servo)) {
        printk("Error: PWM device %s is not ready", pwm_servo.dev->name);
        return 0;
	}


	if(!pwm_is_ready_dt(&pwm_left)) {
		printk("Error: PWM device %s is not ready", pwm_left.dev->name);
		return 0;
	}

	if(!pwm_is_ready_dt(&pwm_right)) {
		printk("Error: PWM device %s is not ready", pwm_right.dev->name);
		return 0;
	}

	while (1) {
		/* 10ms period, 100Hz Sampling frequency */
		k_sleep(K_MSEC(Sampletime));

		sensor_sample_fetch(dev);

		sensor_channel_get(dev, SENSOR_CHAN_ACCEL_XYZ, acc);
		sensor_channel_get(dev, SENSOR_CHAN_GYRO_XYZ, gyr);

				//convesrion formula from sensor.h definition
			   float ax = (acc[0].val1+acc[0].val2*1e-6);
			   float ay = (acc[1].val1+acc[1].val2*1e-6);
			   float az = (acc[2].val1+acc[2].val2*1e-6);

			   //printk("AX: %f; AY: %f; AZ: %f\n", ax, ay, az);

			   //Estimation of the angle using the accelerometer values
			   //Theoretical proof and code from https://www.youtube.com/watch?v=BUW2OdAtzBw
			   float phiHat_acc_g = atanf(ay/az);
			   float thetaHat_acc_g = asinf(ax/Gravity_const);

			   if (isnan(phiHat_acc_g)) {
				   printk("PhiHat is NaN\n");
				   Nancounter++;
				   phiHat_acc_g = 0.0f;
			   }

			   else{}

			   if (isnan(thetaHat_acc_g)) {
				   printk("ThetaHat is NaN\n");
				   thetaHat_acc_g = 0.0f;
			   }

			   else{}

			   //printk("PhiAcc: %f; ThetaAcc: %f\n", phiHat_acc_g, thetaHat_acc_g);

			   //Gyroscope values
			   float gx = (gyr[0].val1+gyr[0].val2*1e-6);
			   float gy = (gyr[1].val1+gyr[1].val2*1e-6);
			   float gz = (gyr[2].val1+gyr[2].val2*1e-6);

			   //printk("GX: %f; GY: %f; GZ: %f\n", gx, gy, gz);

			   float phiDot_rps = gx + tanf(thetaHat_acc_g) * (sinf(phiHat_acc_g) * gy + cosf(phiHat_acc_g) * gz);
			   float thetaDot_rps = cosf(phiHat_acc_g) * gy - sinf(phiHat_acc_g) * gz;

			   	if (isnan(phiDot_rps)) {
				   printk("PhiDot is NaN\n");
				   phiHat_acc_g = 0.0f;
			   }

			   else{}

			   if (isnan(thetaDot_rps)) {
				   printk("ThetaDot is NaN\n");
				   thetaHat_acc_g = 0.0f;
			   }

			   else{}

			   //printk("PhiDot: %f; ThetaDot: %f\n", phiDot_rps, thetaDot_rps);

			   //Complementary filter
			   phiHat = COMP_FILT_ALPHA * phiHat_acc_g + (1.0f - COMP_FILT_ALPHA) * (phiHat + (Sampletime / 1000.0f) * phiDot_rps);
			   thetaHat = COMP_FILT_ALPHA * thetaHat_acc_g + (1.0f - COMP_FILT_ALPHA) * (thetaHat + (Sampletime/1000.0f) * thetaDot_rps);
			   printk("Help: %f; Me: %f;\n", phiHat, thetaHat);
			   writePWMfrominput(ConvertAngleToPWM(led_period(1,phiHat,thetaHat)),ConvertAngleToPWM(led_period(2,phiHat,thetaHat)),ConvertAngleToPWM(led_period(3,phiHat,thetaHat)),ConvertAngleToPWM(led_period(4,phiHat,thetaHat)));



			   //PWM
			   
			if (Nancounter >= 45)
			{
				printk("Too many NaNs\n");
				k_sleep(K_MSEC(1000));
			}

			else{
				task_wdt_feed(task_wdt_id);
			}
			


	}
	return 0;
}

void reset_thread(void)
{
	int task_wdt_id;

	task_wdt_id = task_wdt_add(700U, task_wdt_callback, (void *)k_current_get());

	while(1) {
		if (Nancounter >= 45)
		{
			printk("Too many NaNs\n");
			k_sleep(K_FOREVER);
		}

		else{
			task_wdt_feed(task_wdt_id);
			k_sleep(K_MSEC(Sampletime*5));
		}



	}
}

K_THREAD_DEFINE(reset, 1024, reset_thread, NULL, NULL, NULL, -1, 0, 1000);
