//dea2ef38-9fb4-494c-9070-fd2e40ab523b

#include <zephyr/types.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>

#define BT_UUID_UART_VAL \
    BT_UUID_128_ENCODE(0xdea2ef30,0x9fb4,0x494c,0x9070,0xfd2e40ab523b)

#define BT_UUID_UART_TX_VAL \
    BT_UUID_128_ENCODE(0xdea2ef31,0x9fb4,0x494c,0x9070,0xfd2e40ab523b)

#define BT_UUID_UART_RX_VAL \
    BT_UUID_128_ENCODE(0xdea2ef32,0x9fb4,0x494c,0x9070,0xfd2e40ab523b)


#define BT_UUID_UART    BT_UUID_DECLARE_128(BT_UUID_UART_VAL)
#define BT_UUID_UART_TX BT_UUID_DECLARE_128(BT_UUID_UART_TX_VAL)
#define BT_UUID_UART_RX BT_UUID_DECLARE_128(BT_UUID_UART_RX_VAL)

enum bt_send_status{
    /* send notification enabled*/
    BT_SEND_STATUS_ENABLED,
    /* send notification disabled*/
    BT_SEND_STATUS_DISABLED,
};


struct bt_cb  {
    void (*received)(struct bt_conn *conn, const uint8_t *const data, uint16_t len);
    void (*sent)(struct bt_conn *conn);
    void (*send_enabled)(enum send_status status);
};

int bt_init(struct bt_cb *callbacks);

static inline uint32_t bt_get_mtu(struct bt_conn *conn)
{
    return bt_gatt_get_mtu(conn) -3;
}