#include <zephyr/types.h>
#include <stddef.h>
#include <string.h>
#include <errno.h>
#include <zephyr/sys/printk.h>
#include <zephyr/sys/byteorder.h>
#include <zephyr/kernel.h>

#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/hci.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>
#include "UART_service.h"
#include <zephyr/logging/log.h>

LOG_MODULE_DECLARE(UART_Serivce);

static struct bt_cb bt_cb;
/*
static void ccc_cfg_changed(const struct bt_gatt_attr *attr,
                                uint16_t value)
{
    if (bt_cb.send_enabled) {
        LOG_DBG("Notification has been turned on %s",
                value == BT_GATT_CCC_NOTIFY ? "on" : "off");
        bt_cb.send_enabled(value == BT_GATT_CCC_NOTIFY ?
              BT_SEND_STATUS_ENABLED : BT_SEND_STATUS_DISABLED);
    }
}
*/
static ssize_t tx_cb(struct bt_conn *conn, void *user_data)
{
    ARG_UNUSED(user_data);
    
    LOG_DBG("Data send, conn %p", (void *)conn);

    if (bt_cb.sent) {
        bt_cb.sent(conn);
    }
}

static ssize_t rx_cb(struct bt_conn *conn, const struct bt_gatt_attr *attr, const void *buf, uint16_t len, uint16_t offset, uint8_t flags)
{
    LOG_DGB("Received data, handle %d, conn %p", attr->handle, (void *)conn);

    if(bt_cb.received) {
        bt_cb.received(conn, buf, len);
    }

    return len;
}

static void on_sent(struct bt_conn *conn, void *user_data)
{
    ARG_UNUSED(user_data);

    LOG_DBG("Data send, conn %p", (void *)conn);

    if (bt_cb.sent) {
        bt_cb.sent(conn);
    }
}
BT_GATT_SERVICE_DEFINE(uart_svc,
BT_GATT_PRIMARY_SERVICE(BT_UUID_UART),
BT_GATT_CHARACTERISTIC(BT_UUID_UART_TX,
                BT_GATT_CHRC_NOTIFY,
                BT_GATT_PERM_READ, NULL, NULL,
                NULL),
BT_GATT_CHARACTERISTIC(BT_UUID_UART_RX,
                BT_GATT_CHRC_WRITE,
                BT_GATT_PERM_WRITE, NULL, rx_cb,
                NULL),
);


int bt_init(struct bt_cb *callbacks)
{
    if (callbacks){
        bt_cb.received = callbacks->received;
        bt_cb.sent = callbacks->sent;
        bt_cb.send_enabled = callbacks->send_enabled;
    }

    return 0;
}
