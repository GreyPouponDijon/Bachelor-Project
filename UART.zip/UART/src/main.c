#include <zephyr/kernel.h>
#include <zephyr/types.h>
#include <stddef.h>
#include <errno.h>
#include <zephyr/logging/log.h>
#include <dk_buttons_and_leds.h>
#include <zephyr/sys/printk.h>
#include <zephyr/drivers/gpio.h>
#include <soc.h>
//#include <zephyr/settings/setting.h>
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/gatt.h>
#include <zephyr/bluetooth/hci.h>
#include <bluetooth/services/nus.h>
#include <zephyr/sys/byteorder.h>
#include <bluetooth/gatt_dm.h>
#include <bluetooth/scan.h>
#include "UART_service.h"



#define DEVICE_NAME CONFIG_BT_DEVICE_NAME
#define DEVICE_NAME_LEN (sizeof(DEVICE_NAME)-1)

#define RUN_STATUS_LED DK_LED1

#define CON_STATUS_LED DK_LED2

#define RUN_LED_BLINK_INTERVAL 1000

#define USER_LED DK_LED3

#define USER_BUTTON DK_BTN1_MSK
#define CENTRAL_BUTTON DK_BTN3_MSK
#define PERIPHERAL_BUTTON DK_BTN4_MSK

static void start_scan(void);

//static bool peripheral_toggle;
//static bool central_toggle;

//static K_SEM_DEFINE(ble_init_ok, 0, 1);

static struct bt_conn *current_conn;
static struct bt_conn *default_conn;

typedef enum {
        peripheral_toggle,
        central_toggle,
} ButtonState;


static ButtonState button_state;

static void device_found(const bt_addr_le_t *addr, int8_t rssi, uint8_t type,
                struct net_buf_simple *ad)
{
        char addr_str[BT_ADDR_LE_STR_LEN];
        int err;

        if(default_conn){
                return;
        }

        if (type != BT_GAP_ADV_TYPE_ADV_IND &&
            type != BT_GAP_ADV_TYPE_ADV_DIRECT_IND){
                return;
            }
        
        bt_addr_le_to_str(addr, addr_str, sizeof(addr_str));

        printk("Device found: %s (RSSI %d)", addr_str, rssi);

        if (rssi <-70) {
                return;
        }

        if (bt_le_scan_stop()){
                return;
        }

        err = bt_conn_le_create(addr, BT_CONN_LE_CREATE_CONN,
                        BT_LE_CONN_PARAM_DEFAULT, &default_conn);
        
        if (err) {
                printk("Create conn to %s failed (%d)\n", addr_str, err);
                start_scan();
        }
}

static void start_scan(void)
{
        int err;

        err = bt_le_start_scan(BT_LE_SCAN_PASSIVE, device_found);
        if (err) {
                printk("Scanning failed to start (err %d)\n", err);
                return;
        }

        printk("Scanning successfully started");
}


static const struct bt_data ad[] = {
        BT_DATA_BYTES(BT_DATA_FLAGS, (BT_LE_AD_GENERAL|BT_LE_AD_NO_BREDR)),
        BT_DATA(BT_DATA_NAME_COMPLETE, DEVICE_NAME, DEVICE_NAME_LEN),
};

static const struct bt_data sd[] = {
        BT_DATA_BYTES(BT_DATA_UUID128_ALL, BT_UUID_UART_VAL),
};

static void connected(struct bt_conn *conn, uint8_t err)
{
        char addr[BT_ADDR_LE_STR_LEN];

        if (err) {
                LOG_ERR("Connection failed (err %u)", err);
                return;
        }

        bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));
        LOG_INF("Connected %s", addr);

        current_conn = bt_conn_ref(conn);
        
        dk_set_led_on(CON_STATUS_LED);
}

static void disconnected(struct bt_conn *conn, uint8_t reason)
{
        char addr[BT_ADDR_LE_STR_LEN];

        bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

        LOG_INF("Disconnected: %s (reason %u)", addr, reason);

        if(current_conn) {
                bt_conn_unref(current_conn);
                current_conn = NULL;
        }
        dk_set_led_off(CON_STATUS_LED);
}


BT_CONN_CB_DEFINE(conn_callbacks) = {
        .connected = connected,
        .disconnected = disconnected,
};

/*
static void bt_receive_cb(struct bt_conn *conn, const uint8_t *const data, uint16_t len)
{
        int err;
        char addr[BT_ADDR_LE_STR_LEN] = { 0 };

        bt_addr_le_to_str(bt_conn_get_dst(conn), addr, ARRAY_SIZE(addr));
}
*/

static void button_changed(uint32_t button_state, uint32_t has_changed)
{
        if (has_changed & USER_BUTTON){
                uint32_t user_button_state = button_state & USER_BUTTON;


                bt_send(NULL, user_button_state, sizeof(user_button_state));
        }
        
        if (has_changed & PERIPHERAL_BUTTON){
                printk("peripheral button pressed");
                button_state = peripheral_toggle;
        }

        if (has_changed & CENTRAL_BUTTON){
                button_state = central_toggle;
        }
}

static int init_button(void)
{
        int err;
        
        err = dk_buttons_init(button_changed);
        if (err) {
                printk("Cannot init buttons (err: %d)\n", err);
        }
        return err;
}


int start_central()
{
        int err;
        start_scan();
        return err;
}

int start_peripheral()
{
        int err;

        err = bt_le_adv_start(BT_LE_ADV_CONN, ad, ARRAY_SIZE(ad), sd, ARRAY_SIZE(sd));
        if (err){
                printk("Advertising failed to start (err %d)\n", err);
                return err;
        }
        printk("Advertising successfully started\n");
        return err;
}



void main(void)
{
        int err;

        err = init_button();
        if (err) {
                printk("Button init failed (err %d)\n", err);
                return;
        }

        err = bt_enable(NULL);
        if (err) {
                printk("Bluetooth init failed err(%d)\n", err);
                return;
        }


        printk("Bluetooth initialized\n");

        for(;;){
        switch(button_state)
        {
                case peripheral_toggle:
                        printk("peripheral toggle selected");
                        start_peripheral();
                        
                        break;
                
                case central_toggle:
                        start_central();
                        break;
                
                default:
                        break;
        }

        }

        return;

}





/*
void button_changed(uint32_t button_state, uint32_t has_changed)
{
        uint32_t buttons = button_state & has_changed;
}
static void configure_gpio(void) 
{
        int err;
        err = dk_buttons_init(button_changed);
        if (err) {
                LOG_ERR("Cannot init buttons (err %d)", err);
        }

        err = dk_leds_init();
        if (err) {
                LOG_ERR("Cannot init LEDs (err %d)", err);
        }
}
static void_bt_rece
*/